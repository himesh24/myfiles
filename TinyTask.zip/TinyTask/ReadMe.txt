Hello!

Thank you for Downloading Tinytask - Minimalist autoclicker / automation tool

Visit - thetinytask.com for further support!